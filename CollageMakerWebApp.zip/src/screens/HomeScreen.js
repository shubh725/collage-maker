
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function HomeScreen() {
  const [images, setImages] = useState([]);
  const navigate = useNavigate();

  const selectImage = (e) => {
    const selectedFiles = Array.from(e.target.files).slice(0, 6);
    const imageUrls = selectedFiles.map(file => URL.createObjectURL(file));
    setImages(imageUrls);
  };

  return (
    <div>
      <h2>Choose up to 6 images for your collage</h2>
      <input type="file" multiple accept="image/*" onChange={selectImage} />
      <button onClick={() => navigate('/editor', { state: { images } })}>Create Collage</button>
      <div>
        {images.map((src, index) => (
          <img key={index} src={src} alt={`Selected ${index + 1}`} style={{ width: '100px', height: '100px' }} />
        ))}
      </div>
    </div>
  );
}
