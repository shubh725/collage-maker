
import React, { useState } from 'react';
import { useLocation } from 'react-router-dom';

export default function CollageEditor() {
  const location = useLocation();
  const images = location.state?.images || [];
  const [blendValue, setBlendValue] = useState(0.5);

  const applyBlend = () => {
    // Placeholder for AI blend effect
    alert('Applying AI Blend effect!');
  };

  return (
    <div>
      <h2>Collage Editor</h2>
      <div>
        {images.map((src, index) => (
          <img key={index} src={src} alt={`Collage ${index + 1}`} style={{ width: '100px', height: '100px' }} />
        ))}
      </div>
      <label>Blend Value</label>
      <input
        type="range"
        min="0"
        max="1"
        step="0.01"
        value={blendValue}
        onChange={(e) => setBlendValue(e.target.value)}
      />
      <button onClick={applyBlend}>Apply Blend</button>
      <button onClick={() => alert("Collage Saved!")}>Save Collage</button>
    </div>
  );
}
